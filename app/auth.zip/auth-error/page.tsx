export default function AuthError() {
  return <div>Authentication Error</div>;
}
